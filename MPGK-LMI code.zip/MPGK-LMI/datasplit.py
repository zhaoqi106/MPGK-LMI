import pandas as pd
import numpy as np
import random
num = pd.read_csv('all.csv',delimiter=',',header=None).to_numpy().T
original_matrix = pd.read_csv('intrect_train.txt', delimiter=',', header=None).to_numpy()
new_matrix = np.c_[original_matrix, np.ones(original_matrix.shape[0])]
line1 = original_matrix[:,0]
line2 = original_matrix[:,1]
li = []
for i in range(500):
    print(i)
    num1 = random.randint(0, 283)
    num2 = random.randint(0, 520)
    if [num1,num2,0] in li and [num1,num2] in num:
        continue
    else:
        p = [num1,num2,0]
        li.append(p)
        line1 = np.append(line1,num1)
        line2 = np.append(line2,num2)
new_test = np.concatenate((new_matrix,np.array(li)),axis=0)
num_rows = new_test.shape[0]
shuffled_indices = np.random.permutation(num_rows)
shuffled_array = new_test[shuffled_indices,:]

np.savetxt('train.txt',shuffled_array,delimiter=',',fmt='%d')
