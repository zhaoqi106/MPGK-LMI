# MPGK-LMI: 
## LncRNA-miRNA·interactions·Prediction·based·on meta-path similarity and Gaussian·kernel·similarity


# 

[//]: # (# MODEL:)

[//]: # (![Markdown Logo]&#40;MPGK-LMI.png "Markdown"&#41;)
# <front size=1> Environment:</front>
## matplotlib==3.8.0
## numpy==1.25.2
## pandas==2.2.2
## scikit_learn==1.3.0
## torch==2.0.1
## torch_geometric==2.3.1
## python==3.11.5