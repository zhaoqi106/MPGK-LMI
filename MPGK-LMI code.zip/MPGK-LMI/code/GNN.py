import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from GCN import GCN,GraphAttentionLayer

# class DGCNLayer(nn.Module):
#     """
#         DGCN Module layer
#     """
#     def __init__(self,dim1,dim2,hidden,drop=0.5,alaph=0.1):
#         super(DGCNLayer, self).__init__()
#         self.dropout = 0.5
#         self.gc1 = GCN(
#             nfeat=dim1,
#             nhid=hidden,
#             dropout=drop,
#             alpha=alaph
#         )
#
#         self.gc2 = GCN(
#             nfeat=dim2,
#             nhid=hidden,
#             dropout=drop,
#             alpha=alaph
#         )
#         self.gc3 = GCN(
#             nfeat=hidden, # change
#             nhid=dim1,
#             dropout=drop,
#             alpha=alaph
#         )
#
#         self.gc4 = GCN(
#             nfeat=hidden, # change
#             nhid=dim2,
#             dropout=drop,
#             alpha=alaph
#         )
#         self.user_union = nn.Linear(dim1 + dim1, dim1)
#         self.item_union = nn.Linear(dim2 + dim2, dim2)
#
#     def forward(self, ufea, vfea, U_adj,V_adj):
#         User_ho = self.gc1(ufea, U_adj)
#         Item_ho = self.gc2(vfea, V_adj)
#         User_ho = self.gc3(User_ho, U_adj)
#         Item_ho = self.gc4(Item_ho, V_adj)
#         User = torch.cat((User_ho, ufea), dim=1)
#         Item = torch.cat((Item_ho, vfea), dim=1)
#         User = self.user_union(User)
#         Item = self.item_union(Item)
#         return F.relu(User), F.relu(Item)
class lncLayer(nn.Module):#lnc元路径相似性
    """
        DGCN Module layer
    """
    def __init__(self,dim,hidden,drop=0.5,alaph=0.1):
        super(lncLayer, self).__init__()
        self.dropout = 0.5
        self.gc1 = GraphAttentionLayer(in_features=dim, out_features=hidden, dropout=drop, alpha=alaph)
        # self.gc1 = GCN(
        #     nfeat=dim,
        #     nhid=hidden,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.gcsmi = GraphAttentionLayer(in_features=hidden, out_features=hidden, dropout=drop, alpha=alaph)
        self.gc3 = GraphAttentionLayer(in_features=hidden, out_features=dim, dropout=drop, alpha=alaph)
        # self.gc3 = GCN(
        #     nfeat=hidden, # change
        #     nhid=dim,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.user_union = nn.Linear(dim + dim, dim)

    def forward(self, ufea, U_adj):
        User_ho = self.gc1(ufea, U_adj)
        #User_ho = self.gcsmi(User_ho, U_adj)
        User_ho = self.gc3(User_ho, U_adj)
        User = torch.cat((User_ho, ufea), dim=1)
        User = self.user_union(User)
        return F.relu(User)
class lncsmi(nn.Module):#lnc高斯核相似性
    """
        DGCN Module layer
    """
    def __init__(self,dim,hidden,drop=0.5,alaph=0.1):
        super(lncsmi, self).__init__()
        self.dropout = 0.5
        self.gcsmi1 = GraphAttentionLayer(in_features=dim, out_features=hidden, dropout=drop, alpha=alaph)
        # self.gcsmi1 = GCN(
        #     nfeat=dim,
        #     nhid=hidden,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.gcsmi = GraphAttentionLayer(in_features=hidden, out_features=hidden, dropout=drop, alpha=alaph)
        self.gcsmi2 = GraphAttentionLayer(in_features=hidden, out_features=dim, dropout=drop, alpha=alaph)
        # self.gcsmi2 = GCN(
        #     nfeat=hidden, # change
        #     nhid=dim,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.user_union = nn.Linear(dim + dim, dim)

    def forward(self, ufea, U_smi):
        User_ho = self.gcsmi1(ufea, U_smi)
       # User_ho = self.gcsmi(User_ho, U_smi)
        User_ho = self.gcsmi2(User_ho, U_smi)
        User = torch.cat((User_ho, ufea), dim=1)
        User = self.user_union(User)
        return F.relu(User)
class miLayer(nn.Module):#mi元路径相似性
    """
        DGCN Module layer
    """
    def __init__(self,dim,hidden,drop=0.5,alaph=0.1):
        super(miLayer, self).__init__()
        self.dropout = 0.5
        self.gc2 = GraphAttentionLayer(in_features=dim, out_features=hidden, dropout=drop, alpha=alaph)
        # self.gc2 = GCN(
        #     nfeat=dim,
        #     nhid=hidden,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.gcsmi = GraphAttentionLayer(in_features=hidden, out_features=hidden, dropout=drop, alpha=alaph)
        self.gc4 = GraphAttentionLayer(in_features=hidden, out_features=dim, dropout=drop, alpha=alaph)
        # self.gc4 = GCN(
        #     nfeat=hidden, # change
        #     nhid=dim,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.user_union = nn.Linear(dim + dim, dim)

    def forward(self, ufea, U_adj):
        User_ho = self.gc2(ufea, U_adj)
        #User_ho = self.gcsmi(User_ho, U_adj)
        User_ho = self.gc4(User_ho, U_adj)
        User = torch.cat((User_ho, ufea), dim=1)
        User = self.user_union(User)
        return F.relu(User)
class miLayersmi(nn.Module):#mi高斯核相似性
    """
        DGCN Module layer
    """
    def __init__(self,dim,hidden,drop=0.5,alaph=0.1):
        super(miLayersmi, self).__init__()
        self.dropout = 0.5
        self.gcsmi1 = GraphAttentionLayer(in_features=dim, out_features=hidden, dropout=drop, alpha=alaph)
        # self.gcsmi1 = GCN(
        #     nfeat=dim,
        #     nhid=hidden,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.gcsmi = GraphAttentionLayer(in_features=hidden, out_features=hidden, dropout=drop, alpha=alaph)
        self.gcsmi2 = GraphAttentionLayer(in_features=hidden, out_features=dim, dropout=drop, alpha=alaph)
        # self.gcsmi2 = GCN(
        #     nfeat=hidden, # change
        #     nhid=dim,
        #     dropout=drop,
        #     alpha=alaph
        # )
        self.user_union = nn.Linear(dim + dim, dim)

    def forward(self, ufea, U_adj):
        User_ho = self.gcsmi1(ufea, U_adj)
        #User_ho = self.gcsmi(User_ho,U_adj)
        User_ho = self.gcsmi2(User_ho, U_adj)
        User = torch.cat((User_ho, ufea), dim=1)
        User = self.user_union(User)
        return F.relu(User)
# class LncfeaLayer(nn.Module):
#     """
#         DGCN Module layer
#     """
#     def __init__(self,dim,hidden,drop=0.5,alaph=0.1):
#         super(LncfeaLayer, self).__init__()
#         self.dropout = 0.5
#         self.lnclayer = lncLayer(dim,hidden,drop,alaph)#1
#         self.lncsmi = lncsmi(dim,hidden,drop,alaph)#2
#         self.Liner = nn.Linear(dim*2,dim)
#
#
#     def forward(self, ufea, U_adj,U_smi):
#         fea1 = self.lnclayer(ufea,U_adj)#使用相关性矩阵计算lncRNA特征
#         fea2 = self.lncsmi(ufea,U_smi)#使用高斯核相似性矩阵计算lncRNA特征
#         fea = torch.cat([fea1,fea2],dim=-1)#拼接降维
#         return F.relu(self.Liner(fea))
#
#
# class MifeaLayer(nn.Module):
#     """
#         DGCN Module layer
#     """
#
#     def __init__(self, dim, hidden, drop=0.5, alaph=0.1):
#         super(MifeaLayer, self).__init__()
#         self.dropout = 0.5
#         self.Milayer = miLayer(dim, hidden, drop, alaph)#3
#         self.Mismi = miLayersmi(dim, hidden, drop, alaph)#4
#         self.Liner = nn.Linear(dim * 2, dim)
#
#     def forward(self, ufea, U_adj, U_smi):
#         fea1 = self.Milayer(ufea, U_adj)#使用相关性矩阵计算MiRNA特征
#         fea2 = self.Mismi(ufea, U_smi)#使用高斯核相似性矩阵计算MiRNA特征
#         fea = torch.cat([fea1, fea2], dim=-1)
#         return F.relu(self.Liner(fea))
class SRGE_A(nn.Module):
    def __init__(self):
        super(SRGE_A, self).__init__()
        self.dropout = 0.5
        self.lnclayer = lncLayer(300, 512, self.dropout, 0.1)  # 1
        self.lncsmi = lncsmi(300, 512, self.dropout, 0.1)  # 2
        self.Liner1 = nn.Linear(300 * 2, 300)
        self.Milayer = miLayer(300, 512, self.dropout, 0.1)  # 3
        self.Mismi = miLayersmi(300, 512, self.dropout, 0.1)  # 4
        self.Liner2 = nn.Linear(300 * 2, 300)
        self.score_function1 = nn.Sequential(nn.Linear(600,100),nn.ReLU(inplace=True),nn.Linear(100,10))#得分函数
        self.score_function2 = nn.Sequential(nn.Linear(10,1))#得分函数
    def score_predict(self, fea):

        out = self.score_function1(fea)
        out = F.relu(out)
        out = self.score_function2(out)
        out = torch.sigmoid(out)
        return out.view(out.size()[0], -1)

    def score(self, fea):

        out = self.score_function1(fea)
        out = F.relu(out)

        out = self.score_function2(out)
        out = torch.sigmoid(out)
        return out.view(-1)

    def forward(self, ufea, vfea, UV_adj, VU_adj,uv_smi, vu_smi):
        #lncRNA图嵌入
        fea1 = self.lnclayer(ufea, UV_adj)  # 使用相关性矩阵计算lncRNA特征
        fea2 = self.lncsmi(ufea, uv_smi)  # 使用高斯核相似性矩阵计算lncRNA特征
        feal = torch.cat([fea1, fea2], dim=-1)  # 拼接降维
        lnc_fea = F.relu(self.Liner1(feal))
        #MiRNA图嵌入
        fea3 = self.Milayer(vfea, VU_adj)  # 使用相关性矩阵计算MiRNA特征
        fea4 = self.Mismi(vfea, vu_smi)  # 使用高斯核相似性矩阵计算MiRNA特征
        feam = torch.cat([fea3, fea4], dim=-1)
        mi_fea = F.relu(self.Liner2(feam))


        return lnc_fea,mi_fea