import argparse
import torch
import torch.nn as nn
from sklearn.metrics import roc_curve, auc, precision_recall_curve, f1_score, accuracy_score, average_precision_score
from torch import optim

from utils import *

from datasets import RNADataloader
from torch.utils.data import DataLoader

parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=1, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-6,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=512,
                    help='Dimension of representations')
parser.add_argument('--omega', type=float, default=0.5,
                    help='Weight between lncRNA space and protein space')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()
set_seed(args.seed, args.cuda)
lncrnafeature, mirnafeature, train_label,test_label, edg_lnc, edg_mi = load_data(args.cuda)
lfea = lncrnafeature
mfea = mirnafeature
lnc_smi = gass_smi(lfea)
mi_smi = gass_smi(mfea)

lnc_smi = torch.from_numpy(lnc_smi).float().to('cuda')
mi_smi = torch.from_numpy(mi_smi).float().to('cuda')

adj_lnc = np.zeros([284,284])
adj_lnc[edg_lnc[:, 0], edg_lnc[:, 1]] = 1
adj_mi = np.zeros([520,520])
adj_mi[edg_mi[:, 0], edg_mi[:, 1]] = 1
model = torch.load('../code/output/best.pth').to('cuda')


adj_lnc = torch.from_numpy(adj_lnc).float().to('cuda')
adj_mi = torch.from_numpy(adj_mi).float().to('cuda')


dataset = RNADataloader(train_label)
valset = RNADataloader(test_label)
data = DataLoader(dataset, batch_size=256)
test = DataLoader(valset, batch_size=256)
def adj_max():
    labels = np.loadtxt('../intrect_train.txt',delimiter=',')
    adj = np.zeros([284,520])
    for i in labels:
        adj[int(i[0]),int(i[1])] = 1
    maxis = np.zeros([adj.shape[0]+adj.shape[1],adj.shape[0]+adj.shape[1]])
    #maxis[:adj.shape[0],:adj.shape[0]] = adj_lnc
    maxis[adj.shape[0]:,:adj.shape[0]] = adj.T
    maxis[:adj.shape[0], adj.shape[0]:] = adj
    return np.array(maxis.nonzero())
maxis = torch.from_numpy(adj_max()).long().to('cuda')
def val_model():
    with torch.no_grad():

        for j in range(1):
            list = []
            for i in range(284):#m
                lnc_fea, mi_fea = model(lncrnafeature, mirnafeature, adj_lnc, adj_mi,lnc_smi,mi_smi)
                fea1 = lnc_fea[[i]]
                fea2 = mi_fea[[297]]#m-284
                fea1 = fea1.unsqueeze(1)
                fea2 = fea2.unsqueeze(1)
                fea = torch.cat((fea1, fea2), dim=-1)
                grade = model.score_predict(fea).cpu().detach().numpy()[0][0]
                list.append(grade)
            indices = np.argsort(list)[-10:]
            print(str(j)+'-----------')
            print(indices)
            score = []
            for s in indices:
                score.append(list[s])
            print(score)
val_model()






