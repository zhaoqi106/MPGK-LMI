
import torch
from torch.utils.data import Dataset, DataLoader

class RNADataloader(Dataset):
    def __init__(self,labes):
        super(RNADataloader,self).__init__()
        self.label = labes


    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        data1 = self.label[idx][0]
        data2 = self.label[idx][1]-1
        data = [data1,data2]
        label = self.label[idx][2]
        sample = {'data': data, 'label': label}
        return sample





