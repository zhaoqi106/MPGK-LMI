import torch
import torch.nn as nn

# 定义主胶囊层
class PrimaryCapsuleLayer(nn.Module):
    def __init__(self, in_channels, out_channels, num_capsules, capsule_dimension, kernel_size=9, stride=2):
        super(PrimaryCapsuleLayer, self).__init__()
        self.capsules = nn.ModuleList([
            nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, stride=stride)
            for _ in range(num_capsules)
        ])
        self.capsule_dimension = capsule_dimension

    def forward(self, x):
        batch_size = x.size(0)
        capsules = [capsule(x) for capsule in self.capsules]
        capsules = torch.stack(capsules, dim=1)
        capsules = capsules.view(batch_size, -1, self.capsule_dimension)
        return capsules

# 定义数字胶囊层
class DigitCapsuleLayer(nn.Module):
    def __init__(self, in_capsules, in_dimension, out_capsules, out_dimension, num_routing_iterations=3):
        super(DigitCapsuleLayer, self).__init__()
        self.in_capsules = in_capsules
        self.in_dimension = in_dimension
        self.out_capsules = out_capsules
        self.out_dimension = out_dimension
        self.num_routing_iterations = num_routing_iterations
        self.W = nn.Parameter(torch.randn(1, in_capsules, out_capsules, out_dimension, in_dimension))

    def forward(self, x):
        batch_size = x.size(0)
        x = x.unsqueeze(2)
        x = x.transpose(1, 3)
        x = x.transpose(2, 3)
        u_hat = torch.matmul(self.W, x)
        u_hat = u_hat.squeeze(3)
        u_hat = u_hat.transpose(2, 3)
        u_hat = u_hat.transpose(1, 2)
        b_ij = torch.zeros(batch_size, self.in_capsules, self.out_capsules)

        for iteration in range(self.num_routing_iterations):
            c_ij = nn.functional.softmax(b_ij, dim=2)
            c_ij = c_ij.unsqueeze(3)
            s_j = (c_ij * u_hat).sum(dim=1)
            v_j = self.squash(s_j)

            if iteration < self.num_routing_iterations - 1:
                a_ij = torch.matmul(u_hat, v_j.unsqueeze(2)).squeeze(2)
                b_ij = b_ij + a_ij

        return v_j

    def squash(self, x):
        x_norm = x.norm(dim=2, keepdim=True)
        x_norm_sq = x_norm ** 2
        scale = (x_norm_sq / (1 + x_norm_sq)) / x_norm
        return scale * x

# 创建胶囊网络模型
class CapsuleNet(nn.Module):
    def __init__(self, input_channels, input_dimension, num_classes):
        super(CapsuleNet, self).__init__()
        self.primary_capsules = PrimaryCapsuleLayer(input_channels, 256, 8, 8)
        self.digit_capsules = DigitCapsuleLayer(8, 8, num_classes, 16)
        self.decoder = nn.Sequential(
            nn.Linear(16 * num_classes, 512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 1024),
            nn.ReLU(inplace=True),
            nn.Linear(1024, input_dimension * input_channels),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.primary_capsules(x)
        x = self.digit_capsules(x)
        x = x.view(x.size(0), -1)
        classes = x.norm(dim=2)
        return x, classes


