import numpy as np
import torch


def set_seed(seed, cuda):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if cuda:
        torch.cuda.manual_seed(seed)


def load_data(cuda):
    rnafeature = np.loadtxt('', delimiter=' ', encoding='UTF-8-sig')
    profeature = np.loadtxt('', delimiter=' ', encoding='UTF-8-sig')
    train_label = np.loadtxt('',delimiter=',')
    test_label = np.loadtxt('', delimiter=',')
    edg_lnc = np.loadtxt('', delimiter=',', encoding='UTF-8-sig')
    edg_mi = np.loadtxt('', delimiter=',', encoding='UTF-8-sig')
    rnafeature_torch = torch.from_numpy(rnafeature).float()
    profeature_torch = torch.from_numpy(profeature).float()
    train_label = torch.from_numpy(train_label).long()
    test_label = torch.from_numpy(test_label).long()
    edg_lnc = torch.from_numpy(edg_lnc).long()
    edg_mi = torch.from_numpy(edg_mi).long()



    if cuda:
        lncrnafeature = rnafeature_torch.cuda()
        mirnafeature = profeature_torch.cuda()
        edg_lnc = edg_lnc
        edg_mi = edg_mi
        train_label = train_label.cuda()
        test_label = test_label.cuda()
    return lncrnafeature, mirnafeature, train_label,test_label, edg_lnc, edg_mi




def normalized(wmat):
    deg = np.diag(np.sum(wmat, axis=0))
    degpow = np.power(deg, -0.5)
    degpow[np.isinf(degpow)] = 0
    W = np.dot(np.dot(degpow, wmat), degpow)
    return W


def metrix_convert(A):
    for i in range(len(A)):
        if A[i] >= 0.5:
            A[i] = 1
        else:
            A[i] = 0
    return A

def scaley(y):
    return (y - y.min()) / y.max()

def LineMix(matrix1,matrix2):
    alpha = 1
    beta = 1
    # 线性融合
    result_matrix = alpha * matrix1 + beta * matrix2
    return result_matrix
def gaussian_kernel_similarity(v1, v2, sigma):
    distance = np.linalg.norm(v1 - v2)
    similarity = np.exp(-distance**2 / (2 * sigma**2))
    return similarity

def gass_smi(fea):
    fea = fea.cpu().numpy()
    # 带宽参数
    sigma = 1.0

    # 初始化高斯核相似性矩阵
    num_lncRNAs = len(fea)
    GSL_matrix = np.zeros((num_lncRNAs, num_lncRNAs))

    # 计算高斯核相似性矩阵
    for i in range(num_lncRNAs):
        for j in range(num_lncRNAs):
            GSL_matrix[i,j] = gaussian_kernel_similarity(fea[i], fea[j], sigma)

    return GSL_matrix

