import argparse

import pandas as pd
import torch
from matplotlib import pyplot as plt
import torch.nn as nn
from sklearn.metrics import roc_curve, auc, precision_recall_curve, f1_score, accuracy_score, average_precision_score
from torch import optim
import numpy as np
from utils import *
#from models import BiGI
from datasets import RNADataloader
from torch.utils.data import DataLoader

parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=1, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-6,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=512,
                    help='Dimension of representations')
parser.add_argument('--omega', type=float, default=0.5,
                    help='Weight between lncRNA space and protein space')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()
set_seed(args.seed, args.cuda)
lncrnafeature, mirnafeature, train_label,test_label, edg_lnc, edg_mi = load_data(args.cuda)
lfea = lncrnafeature
mfea = mirnafeature
lnc_smi = gass_smi(lfea)
mi_smi = gass_smi(mfea)
adj_lnc = np.zeros([284,284])
adj_lnc[edg_lnc[:, 0], edg_lnc[:, 1]] = 1
adj_mi = np.zeros([520,520])
adj_mi[edg_mi[:, 0], edg_mi[:, 1]] = 1
model = torch.load('./output/best.pth').to('cuda')

# adj_lnc = 0.6*lnc_smi + 0.4*adj_lnc
# adj_mi = 0.6*mi_smi + 0.4*adj_mi
adj_lnc = torch.from_numpy(adj_lnc).float().to('cuda')
adj_mi = torch.from_numpy(adj_mi).float().to('cuda')
lnc_smi = torch.from_numpy(lnc_smi).float().to('cuda')
mi_smi = torch.from_numpy(mi_smi).float().to('cuda')
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001,weight_decay=0.0001)  # 随机梯度下降优化器
dataset = RNADataloader(train_label)
valset = RNADataloader(test_label)
data = DataLoader(dataset, batch_size=32)
test = DataLoader(valset, batch_size=32)


def plot(scores,labels):
    predictions = list(zip(scores, labels))
    predictions.sort(reverse=True)  # 按照预测得分降序排列

    # 计算TPR和FPR
    num_positive = sum(labels)
    num_negative = len(labels) - num_positive
    tpr = [0]  # 初始值
    fpr = [0]  # 初始值
    for _, label in predictions:
        if label == 1:
            tpr.append(tpr[-1] + 1 / num_positive)
            fpr.append(fpr[-1])
        else:
            tpr.append(tpr[-1])
            fpr.append(fpr[-1] + 1 / num_negative)
    # 计算AUC
    np.save('../myres.npy', tpr)
    np.save('../myfpr.npy', fpr)
    auc = np.trapz(tpr, fpr)
    # pd.DataFrame(fpr).to_csv("./fpr_xjx.csv")
    # pd.DataFrame(tpr).to_csv("./tpr_xjx.csv")
    # 绘制ROC曲线
    plt.plot(fpr, tpr, label=f'AUC = {auc:.2f}')
    plt.plot([0, 1], [0, 1], 'k--')  # 对角线
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curve')
    plt.legend()
    plt.grid(True)
    plt.show()
def adj_max():
    labels = np.loadtxt('../intrect_train.txt',delimiter=',')
    adj = np.zeros([284,520])
    for i in labels:
        adj[int(i[0]),int(i[1])] = 1
    maxis = np.zeros([adj.shape[0]+adj.shape[1],adj.shape[0]+adj.shape[1]])
    #maxis[:adj.shape[0],:adj.shape[0]] = adj_lnc
    maxis[adj.shape[0]:,:adj.shape[0]] = adj.T
    maxis[:adj.shape[0], adj.shape[0]:] = adj
    return np.array(maxis.nonzero())
maxis = torch.from_numpy(adj_max()).long().to('cuda')
def val_model():
    with torch.no_grad():
        best_mode = 0.9
        pre = np.array([])
        tar = np.array([])
        auroc_l, aupr_l, acc_l, f1_l, pre_l,len = 0,0,0,0,0,0
        for batch_data in test:
            lnc_fea, mi_fea = model(lncrnafeature, mirnafeature, adj_lnc, adj_mi,lnc_smi,mi_smi)
            fea1 = lnc_fea[batch_data['data'][0]]
            fea2 = mi_fea[batch_data['data'][1]]
            # fea1 = lnc_fea[[36]]
            # fea2 = mi_fea[[81]]
            fea1 = fea1.unsqueeze(1)
            fea2 = fea2.unsqueeze(1)
            target = batch_data['label'].cpu().detach().numpy()
            fea = torch.cat((fea1, fea2), dim=-1)
            grade = model.score_predict(fea).squeeze(1).cpu().detach().numpy()
            # if batch_data['data'][0]==79:
            #     print(grade)
            # predicted = (grade > 0.5).int()
            # if args.cuda:
            #     predicted = predicted.squeeze(1).cpu().detach().numpy()
            #     target = target.cpu().detach().numpy()
            # else:
            #     predicted = predicted.squeeze(1).detach().numpy()
            #     target = target.cpu().detach().numpy()

            tar = np.concatenate((tar, target), axis=0)
            pre = np.concatenate((pre, grade), axis=0)
        plot(pre, tar)
        auroc, aupr, acc, f1, prece = result(pre, tar)
            # auroc, aupr, acc, f1, pre = result(predicted,target)
            # auroc_l += auroc
            # aupr_l += aupr
            # acc_l += acc
            # f1_l += f1
            # pre_l += pre
            # len += 1
        # if auroc_l/len >= best_mode:
        #     best_mode = auroc_l/len
        #     torch.save(model,'./output/best.pth')
        # plot(pre, tar)
        print('AUROC= %.4f | AUPR= %.4f | ACC= %.4f | F1_score= %.4f | precision= %.4f' % (auroc, aupr, acc, f1, prece))


def result(pre,target):
    y_true = target
    y_pred = pre
    fpr, tpr, rocth = roc_curve(y_true, y_pred)
    auroc = auc(fpr, tpr)

    np.save('../myres.npy', tpr)
    np.save('../myfpr.npy', fpr)
    precision, recall, prth = precision_recall_curve(y_true, y_pred)
    aupr = auc(recall, precision)
    y_pred_convert = metrix_convert(y_pred)
    f1 = f1_score(y_true, y_pred_convert.astype(np.int64))
    acc = accuracy_score(y_true, y_pred_convert.astype(np.int64))
    pre = average_precision_score(y_true, y_pred.astype(np.int64))
    return auroc, aupr, acc, f1, pre

val_model()






