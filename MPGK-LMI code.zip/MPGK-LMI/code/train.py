import argparse

from matplotlib import pyplot as plt
import torch.nn as nn
from sklearn.metrics import roc_curve, auc, precision_recall_curve, f1_score, accuracy_score, average_precision_score
from torch import optim

from utils import *
from models import MPGK_LMI #BiGI,
from datasets import RNADataloader
from torch.utils.data import DataLoader

parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=1, help='Random seed.')
parser.add_argument('--epochs', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-6,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=1024,
                    help='Dimension of representations')
parser.add_argument('--omega', type=float, default=0.5,
                    help='Weight between lncRNA space and protein space')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()
set_seed(args.seed, args.cuda)
lncrnafeature, mirnafeature, train_label,test_label, edg_lnc, edg_mi = load_data(args.cuda)
lfea = lncrnafeature
mfea = mirnafeature
lnc_smi = gass_smi(lfea)
mi_smi = gass_smi(mfea)
adj_lnc = np.zeros([284,284])
adj_lnc[edg_lnc[:, 0], edg_lnc[:, 1]] = 1
adj_mi = np.zeros([520,520])
adj_mi[edg_mi[:, 0], edg_mi[:, 1]] = 1
model = MPGK_LMI().to('cuda')

# adj_lnc = 0.6*lnc_smi + 0.4*adj_lnc
# adj_mi = 0.6*mi_smi + 0.4*adj_mi
adj_lnc = torch.from_numpy(adj_lnc).float().to('cuda')
adj_mi = torch.from_numpy(adj_mi).float().to('cuda')
lnc_smi = torch.from_numpy(lnc_smi).float().to('cuda')
mi_smi = torch.from_numpy(mi_smi).float().to('cuda')
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)  # 随机梯度下降优化器
dataset = RNADataloader(train_label)
valset = RNADataloader(test_label)
data = DataLoader(dataset, batch_size=32)
test = DataLoader(valset, batch_size=32)
def adj_max():
    labels = np.loadtxt('../intrect_train.txt',delimiter=',')
    adj = np.zeros([284,520])
    for i in labels:
        adj[int(i[0]),int(i[1])] = 1
    maxis = np.zeros([adj.shape[0]+adj.shape[1],adj.shape[0]+adj.shape[1]])
    #maxis[:adj.shape[0],:adj.shape[0]] = adj_lnc
    maxis[adj.shape[0]:,:adj.shape[0]] = adj.T
    maxis[:adj.shape[0], adj.shape[0]:] = adj
    return np.array(maxis.nonzero())
maxis = torch.from_numpy(adj_max()).long().to('cuda')
def val_model():
    with torch.no_grad():
        best_mode = 0.65
        auroc_l, aupr_l, acc_l, f1_l, pre_l,len = 0,0,0,0,0,0
        pre = np.array([])
        tar = np.array([])
        for batch_data in test:
            lnc_fea, mi_fea = model(lncrnafeature, mirnafeature, adj_lnc, adj_mi,lnc_smi,mi_smi)
            fea1 = lnc_fea[batch_data['data'][0]]
            fea2 = mi_fea[batch_data['data'][1]]
            fea1 = fea1.unsqueeze(1)
            fea2 = fea2.unsqueeze(1)
            target = batch_data['label']
            fea = torch.cat((fea1, fea2), dim=-1)
            grade = model.score_predict(fea)
            predicted = (grade > 0.5).int()
            if args.cuda:
                predicted = predicted.squeeze(1).cpu().detach().numpy()
                target = target.cpu().detach().numpy()
            else:
                predicted = predicted.squeeze(1).detach().numpy()
                target = target.cpu().detach().numpy()
            pre = np.concatenate((pre, predicted), axis=0)
            tar = np.concatenate((tar, target), axis=0)
        auroc, aupr, acc, f1, pre = result(pre,tar)
        if auroc >= best_mode:
            #best_mode = auroc_l
            torch.save(model,'./output/642.pth')
            print('save')
        print('AUROC= %.4f | AUPR= %.4f | ACC= %.4f | F1_score= %.4f | precision= %.4f' % (auroc, aupr, acc, f1, pre))
def result(pre,target):
    y_true = target
    y_pred = pre
    fpr, tpr, rocth = roc_curve(y_true, y_pred)
    auroc = auc(fpr, tpr)

    precision, recall, prth = precision_recall_curve(y_true, y_pred)
    aupr = auc(recall, precision)
    y_pred_convert = metrix_convert(y_pred)
    f1 = f1_score(y_true, y_pred_convert.astype(np.int64))
    acc = accuracy_score(y_true, y_pred_convert.astype(np.int64))
    pre = average_precision_score(y_true, y_pred.astype(np.int64))

    return auroc, aupr, acc, f1, pre
# 训练模型
num_epochs = 300
for epoch in range(num_epochs):
    len = 0
    total_loss = 0.0
    all_fpr = 0.0
    all_tpr = 0.0
    for batch in data:
        # 梯度清零
        optimizer.zero_grad()
        lnc_fea, mi_fea = model(lncrnafeature, mirnafeature, adj_lnc, adj_mi,lnc_smi,mi_smi)
        fea1 = lnc_fea[batch['data'][0]]
        fea2 = mi_fea[batch['data'][1]]
        fea1 = fea1.unsqueeze(1)
        fea2 = fea2.unsqueeze(1)
        target = batch['label']
        fea = torch.cat((fea1, fea2), dim=-1)
        grade = model.score(fea)
        # grade = grade[0].float()
        # 计算损失
        loss = criterion(grade, target.float())
        # 反向传播和优化
        loss.backward()
        optimizer.step()
        total_loss += loss
        len += 1
    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {total_loss.item()/len:.4f}')
    if epoch % 20 ==0:
       val_model()
val_model()
def plot(fpr,tpr):
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")
    plt.show()






