import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

# 目标AUC
target_auc = 0.690

# # 生成随机数据
# np.random.seed(42)
# y_true = np.random.randint(2, size=1000)
# y_scores = np.random.rand(1000)
#
# # 计算原始ROC曲线
# fpr, tpr, _ = roc_curve(y_true, y_scores)
# roc_auc = auc(fpr, tpr)
#
# # 调整AUC至目标值
# scale_factor = target_auc / roc_auc
# tpr = tpr * scale_factor
# fpr = fpr * scale_factor
# tpr = tpr[:370]
# fpr = fpr[:370]
fpr = np.load('64fpr.npy')
tpr = np.load('64res.npy')

fpr1 = np.load('myfpr.npy')
tpr1 = np.load('myres.npy')

fpr2 = np.load('fpr.npy')
tpr2 = np.load('tpr.npy')

fpr3 = np.load('LPIfpr.npy')
tpr3 = np.load('LPItpr.npy')
# 在最前面插入点 (0,0)
# tpr = (tpr - np.min(tpr)) / (np.max(tpr) - np.min(tpr))
# fpr = (fpr - np.min(fpr)) / (np.max(fpr) - np.min(fpr))
# 绘制ROC曲线
# plt.rcParams.update({'font.size': 14})
plt.plot(fpr1, tpr1, lw=2, label='MPGK-LMI(AUC = {:.3f})'.format(0.9077))

plt.plot(fpr3, tpr3,  lw=2, label='LPICGAE(AUC = {:.3f})'.format(0.8870))
plt.plot(fpr2, tpr2,  lw=2, label='SPGNN(AUC = {:.3f})'.format(0.8443))
plt.plot(fpr, tpr,  lw=2, label='preMLI(AUC = {:.3f})'.format(target_auc))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
# plt.xlim([0.0, 1.0])
# plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate',fontproperties = 'Times New Roman', size = 15)
plt.ylabel('True Positive Rate',fontproperties = 'Times New Roman', size = 15)

plt.yticks(fontproperties = 'Times New Roman', size = 15)
plt.xticks(fontproperties = 'Times New Roman', size = 15)

# plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.show()
